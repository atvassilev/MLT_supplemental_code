#!/usr/bin/env python
# coding: utf-8

# # Final release for publication


## First command to run
## Get reproducible results
start_seed = 42
from numpy.random import seed
seed(start_seed)

import tensorflow as tf
tf.random.set_seed(start_seed)


# # MLT Combiners and MLT-plus-TM: Combine individual models using linear decomposition 
# 
# **Datasets**
# - Predicted probability files created on CAD dev dataset from inferences on individual models trained using  CAD training dataset.
# - Predicted probabilities of CAD Dev are used in training combiner weights. After combination, threshold values are then trained using the combined probabilities to maximum macro average F1 scores.
# - Use combiner weights to create MLT on CAD test dataset and apply threshold values through TM on CAD test datasets.
#     
# **Linear decomposition**
# - In CAD, there are 5 classes. We train 5 seperate binary classifiers using one-vs-all method. Because of this, there are also 5 seperate combiners. 
# - CAD dev is used in training combiner and optimal threshold in linear combiner. These values are then used in threshold moving after the combined result to achive better metrics such as F1 scores. Threshold moving training is binary in nature because this is done for each individual class.
# 
# **Run setup**
# - All participating model has its own subfolder where its CAD dev and test predicted probabilify files are located.
# - Each dev and test pair from a model is selected to join a run where a run is from all participating models. The total permutations is the total runs of combiners. The result is reported based on mean of total runs with their standard deviations. For example, if there are 3 participating models, and each model has 2 pairs of dev/test predicted probability files, the total run number is 2x2x2 = 8. Similarly, total run number for combining 5 models is 32.


import pandas as pd
import numpy as np

import os
import sys
import glob
import itertools
from operator import itemgetter


from numpy import mean
from numpy import std
import matplotlib.pyplot as plt

from tensorflow.keras.models import  Model
from tensorflow.keras.layers import Input, Dense, Dropout
from tensorflow.keras.optimizers import Adam
from numpy import argmax

from sklearn.metrics import accuracy_score,  classification_report, f1_score
from tensorflow.keras.models import Sequential


## Data locations
base_dir = './data/'

# Individual model data locations
bert_dir = "./bert/"
bertweet_dir = "./btweet/"
bigbird_dir = "./bigbird/"
bloom_dir = "./bloom/"
xlnet_dir = "./xlnet/"


## Individual models participating combiners
model_dic = {
    'm1': "bigbird",
    'm2': "bert",
    'm3': "bertweet",
    "m4": "bloom",
    "m5": "xlnet"
}

## Individual model data locations
model_locs = {
    'm1': bigbird_dir,
    'm2': bert_dir,
    'm3': bertweet_dir,
    "m4": bloom_dir,
    "m5": xlnet_dir
}
models = ['m1', 'm2', 'm3', 'm4', 'm5']
#models = ['m1','m3']
## CAD data columns (classes)
cols = ['0', '1', '2', '3', '4']
## accuracy constraint used in TM
acc_constraint = 0.75


classes = ['Neutral',  'IdentityDirectedAbuse', 'AffiliationDirectedAbuse', 'PersonDirectedAbuse', 'CounterSpeech']


# # Load CAD Dev and Test predicted prob files and labels (true_y). Every runs has a different sequence of records so every run comes with a different prob file and true_y file. This is due to multi-threading using multiple GPUs.


prob_file_pattern = '_prob'
dev_file_pattern = '_dev'
test_file_pattern = '_te'
label_file_pattern = '_label'
csv_file_pattern = '*.csv'


# keep track of individual model run history. 
# Only run an single model run one
global_individual_run_list = list()
for model in models:
    # results for all individual runs
    globals() [f"{model}_results"] = list()


for category in classes:
    # MLT results per category
    globals() [f"MLT_{category}_recalls"] = list()
    globals() [f"MLT_{category}_precisions"] = list()
    globals() [f"MLT_{category}_f1s"] = list()
    
    # MLT-plus-TM results per category
    globals() [f"MLT_TM_{category}_recalls"] = list()
    globals() [f"MLT_TM_{category}_precisions"] = list()
    globals() [f"MLT_TM_{category}_f1s"] = list()


# global Log information holder
contents = []


## Display and log a content
def log_content(content):
    contents.append(content)
    if isinstance(content, list):
        for i in content:
            print(i)
    else:
        print(content)


# Output predicted proabilities.
def output_cad_prob_file(df_data, file_root_name, prediction_prob, y_fields, id_field):
    df_final = pd.DataFrame(df_data)
    
    df_final[y_fields] = prediction_prob
    
    fields = copy.copy(y_fields)
    fields.append(id_field)

    # Create .csv file including prediction probability, and the file name where the review is from
    result_file_name = file_root_name + ".csv"
    df_final.to_csv(result_file_name, index=False, columns = fields, float_format='%.6f')


def get_participating_model_performance_1(file_pair, test_prob, cad_test_y_true):
    header = "The participated model file pair are \n{}\n{}".format(file_pair[0], file_pair[1])
    print(header)
    contents.append(header)
    cad_test_y_pred = np.round(test_prob)
    header = "Performance for this model:"
    log_performance(header, cad_test_y_true, cad_test_y_pred)


## Get metric performance
## y_true: true values
## y_pred: predicted values
## return: metric results
def get_performance(y_true, y_pred):
    classi_report_dict = classification_report(y_true, y_pred, zero_division=1, digits=4, output_dict=True)
    classi_report_str = classification_report(y_true, y_pred, zero_division=1, digits=4)
    acc = accuracy_score(y_true, y_pred)
    f1 = f1_score(y_true, y_pred, average ='macro')
    roc = 0.0 # for multi-class, this has no value
    # only for binary classifier print("Confusion matrix is \n{}".format(confusion_matrix(y_true, y_pred)))
    return [[classi_report_dict, classi_report_str], acc, f1, roc]


## Prepare train and test dictionaries that are used in linear combiner
## models: participating individual model ids
## cols: column positioning numbers
def get_dics_for_linear_combiner_1(models, train_X, test_X, train_y, test_y):
    ## Load data from probability created from CAD dev and test
    i = 0
    for x in models:
        globals()[f"df_{x}_dev_prob"] = train_X[i]
        globals()[f"df_{x}_test_prob"] = test_X[i]
        i = i+1
    ## Example: dev prob from model 1
    # df_m1_dev_prob = pd.read_csv(model_1_dev_prob, usecols=[0,1,2,3,4])
    ## test prob from model 1
    # df_m1_test_prob = pd.read_csv(model_1_test_prob, usecols=[0,1,2,3,4])
    
    ## Prepare train data for linear combiner in each column
    for x in models:
        for c in cols:
            globals()[f"col"] = eval(f"{c}")
            globals()[f"train_{x}_c{c}_X"] = eval(f"df_{x}_dev_prob[df_{x}_dev_prob.columns[col]]")
            globals()[f"test_{x}_c{c}_X"] = eval(f"df_{x}_test_prob[df_{x}_test_prob.columns[col]]")

    ## Example:
    # train_m1_c0_X = df_m1_dev_prob[df_m1_dev_prob.columns[0]]
    # train_m1_c1_X = df_m1_dev_prob[df_m1_dev_prob.columns[1]]

    # train_m2_c0_X = df_m2_dev_prob[df_m2_dev_prob.columns[0]]
    # train_m2_c1_X = df_m2_dev_prob[df_m2_dev_prob.columns[1]]

    # test_m1_c0_X = df_m1_test_prob[df_m1_test_prob.columns[0]]
    # test_m1_c1_X = df_m1_test_prob[df_m1_test_prob.columns[1]]

    # test_m2_c0_X = df_m2_test_prob[df_m2_test_prob.columns[0]]
    # test_m2_c1_X = df_m2_test_prob[df_m2_test_prob.columns[1]]
    
    ## Prepare train and test data for each column for linear combiner.
    ## Combine each column from each individual model into one data 
    for c in cols:
        train_data_dic = {}
        test_data_dic = {}
        globals()[f"col"] = eval(f"{c}")
        for x in models:
            globals() [f"{x}"] = eval(f"train_{x}_c{c}_X")
            train_data_dic.update({f"{x}": eval(f"train_{x}_c{c}_X")})
            globals() [f"{x}"] = eval(f"test_{x}_c{c}_X")
            test_data_dic.update({f"{x}": eval(f"test_{x}_c{c}_X")})
        globals() [f"train_linear_c{c}_X"] = pd.DataFrame.from_dict(train_data_dic)
        globals() [f"train_linear_c{c}_y"] = train_y[train_y.columns[col]]
        globals() [f"test_linear_c{c}_X"] = pd.DataFrame.from_dict(test_data_dic)
        if(test_y is None):
            globals() [f"test_linear_c{c}_y"] = None
        else:
            globals() [f"test_linear_c{c}_y"] = test_y[test_y.columns[col]]

    ## Example:
    # train_linear_c0_X = pd.DataFrame(
    #     {'m1': train_m1_c0_X,
    #      'm2': train_m2_c0_X,
    #      'm3': train_m3_c0_X,
    #      'm4': train_m4_c0_X,
    #      'm5': train_m5_c0_X
    #     })
    # train_linear_c0_y = train_y[train_y.columns[0]]

    # train_linear_c1_X = pd.DataFrame(
    #     {'m1': train_m1_c1_X,
    #      'm2': train_m2_c1_X,
    #      'm3': train_m3_c1_X,
    #      'm4': train_m4_c1_X,
    #      'm5': train_m5_c1_X
    #     })
    # train_linear_c1_y = train_y[train_y.columns[1]]

    # test_linear_c0_X = pd.DataFrame(
    #     {'m1': test_m1_c0_X,
    #      'm2': test_m2_c0_X,
    #      'm3': test_m3_c0_X,
    #      'm4': test_m4_c0_X,
    #      'm5': test_m4_c0_X
    #     })
    # test_linear_c0_y = test_y[test_y.columns[0]]

    # test_linear_c1_X = pd.DataFrame(
    #     {'m1': test_m1_c1_X,
    #      'm2': test_m2_c1_X,
    #      'm3': test_m3_c1_X,
    #      'm4': test_m4_c1_X,
    #      'm5': test_m4_c1_X
    #     })
    # test_linear_c1_y = test_y[test_y.columns[1]]
    
    ## Train and test data for all individual classes for linear combiners
    train_data_linear_dic = {}
    test_data_linear_dic = {}
    for c in cols:
        globals() [f"classes[col]"] = (eval(f"train_linear_c{c}_X"), 
                                           eval(f"train_linear_c{c}_y"))
        train_data_linear_dic.update({eval(f"classes[{c}]") : (eval(f"train_linear_c{c}_X"), 
                                           eval(f"train_linear_c{c}_y"))})
        globals() [f"classes[col]"] = (eval(f"test_linear_c{c}_X"), 
                                           eval(f"test_linear_c{c}_y"))
        test_data_linear_dic.update({eval(f"classes[{c}]") : (eval(f"test_linear_c{c}_X"), 
                                           eval(f"test_linear_c{c}_y"))})
    ## Example:
    # train_data_linear_dic = {
    #     classes[0]: (train_linear_c0_X, train_linear_c0_y),
    #     classes[1]: (train_linear_c1_X, train_linear_c1_y),
    #     classes[2]: (train_linear_c2_X, train_linear_c2_y),
    #     classes[3]: (train_linear_c3_X, train_linear_c3_y),
    #     classes[4]: (train_linear_c4_X, train_linear_c4_y)
    # }

    # test_data_linear_dic = {
    #     classes[0]: (test_linear_c0_X, test_linear_c0_y),
    #     classes[1]: (test_linear_c1_X, test_linear_c1_y),
    #     classes[2]: (test_linear_c2_X, test_linear_c2_y),
    #     classes[3]: (test_linear_c3_X, test_linear_c3_y),
    #     classes[4]: (test_linear_c4_X, test_linear_c4_y)
    # } 
    return train_data_linear_dic, test_data_linear_dic


## Send performance results to a buffer for later display and log
## header: Starting header for a task
## y_true: true y values
## y_pred: predicted y values
def log_performance(header, y_true, y_pred):
    # Set decimal format
    np.set_printoptions(formatter={'float': lambda x: "{0:0.4f}".format(x)})
    local_contents = list()
    
    local_contents.append(header)
    
    classi_reports, acc, f1, roc = get_performance(y_true, y_pred)
    
    acc_str = 'Accuracy is >'
    local_contents.append(acc_str)
    local_contents.append(acc)
    
    f1_str = "Macro F1 score is >"
    local_contents.append(f1_str)
    local_contents.append(f1)
    
    classification_report_str = "Classification results are >"
    local_contents.append(classification_report_str)
    local_contents.append(classi_reports[1])
    
    log_content(local_contents)
    return  [classi_reports, acc, f1, roc]


## calculate best f1 score for one class. ytrue and yhat are one dimension data.
## The metric to maximize is macro F1. The calibrated threshold is in the middle of the
## min and max range of thresholds. The range is 99% and above of the maximum macro F1 score
## average_type: 'binary' or 'macro'. Use 'binary' in CAD, use 'macro' in Hatecheck
def get_best_pr(ytrue, y_pred_prob, average_type, acc_constraint):
    # define thresholds
    from numpy import arange
    thresholds = arange(0.00001, 1, 0.001)
    # evaluate each threshold
    f1_scores = [f1_score(ytrue, to_labels(y_pred_prob, t), average=average_type)               for t in thresholds]
    
    # get best threshold
    ix = argmax(f1_scores)
    acc_score = accuracy_score(ytrue, to_labels(y_pred_prob, thresholds[ix]))
    if acc_score < acc_constraint:
        return 0.5
    return thresholds[ix]


## Get linear combiner model. Input shape equals to number of particupating models.
## Each column represents predicted probability values of one class from each participating model
## model_num: number of participating models
## return: linear combiner
def get_linear_combiner(model_num):
    model = Sequential()
    # uses 'tanh' activation
    model.add(Dense(1, activation='tanh',
            kernel_regularizer=tf.keras.regularizers.L1L2(l1=1e-5, l2=1e-4),
            bias_regularizer=tf.keras.regularizers.l2(1e-4),
            activity_regularizer=tf.keras.regularizers.l2(1e-5),
            input_shape=(model_num,), name="hidden1_layer"))
    model.add(Dense(1, activation="sigmoid", name="prediction_layer"))

    # model.summary()
    return model


## Train a linear combiner for target class
## model: model to train
## train_data: train data including train and validation data
## hyper_paras: model hypermarameters
def train_linear_combiner(model, data, hyper_params):
    train_X, train_y = data[0][0], data[0][1]
    val_X, val_y = data[1][0], data[1][1]
    
    loss, metrics, epoch, batch_size, l_rate = hyper_params[0], hyper_params[1],hyper_params[2],hyper_params[3],hyper_params[4]
    
    opt = Adam(learning_rate=l_rate)
    model.compile(optimizer=opt, 
          loss=loss,
          metrics=metrics)
    
    history = model.fit(train_X, train_y,
    #validation_split=0.3, # Used in tuning
    validation_data=(val_X, val_y),
    epochs=epoch,
    batch_size=batch_size,
    shuffle=True,
    verbose = 0)
    
    history.history
    
    return model


## Train linear combiner for each class, and train optimal threshold from training data for each class in the process
## The final combiner is the concatenation of individul combiners
## model: the model used to train individual linear combiner 
## 
def train_linear_and_thresholds(models, train_data_linear_dic, test_data_linear_dic, columns):
    LOSS = 'binary_crossentropy'
    METRICS = ['accuracy']
    EPOCH = 50 # same as in MLT B-C as both are binary in nature
    BATCH_SIZE = 64
    #LRATE = 0.005 
    LRATE = 0.001
    
    # Epoch for each class. Default to EPOCh
    #epochs = [100, 200, 200, 200, 200]
    hyper_params = [LOSS, METRICS, EPOCH, BATCH_SIZE, LRATE]
    
    
    ## probability values for every class
    df_test_pred_prob_all_columns = pd.DataFrame()
    df_train_pred_prob_all_columns = pd.DataFrame()
    ## selected threshold values for every class
    df_thresholds = []

    ## Fit data for 5 classes individually
    for i in range(5):
        train_data = list(train_data_linear_dic.values())[i]
        train_data_X = train_data[0]
        train_data_y = train_data[1]
        test_data = list(test_data_linear_dic.values())[i]
        test_data_X = test_data[0]
        test_data_y = test_data[1]
        
        # Get a linear combiner
        model = get_linear_combiner(len(models))
        trained_linear_model = train_linear_combiner(model, [train_data, test_data], hyper_params)
        # Resuslt for individual class by linear combiner
        #test_linear_results = trained_linear_model.evaluate(test_data_X, test_data_y, batch_size=BATCH_SIZE)
#         print("Linear Test evaluation results for class {0} are:\n{1} "
#           .format(list(train_data_linear_dic.keys())[i], test_linear_results))
        test_linear_prediction_prob = trained_linear_model.predict(test_data_X)
        train_linear_prediction_prob = trained_linear_model.predict(train_data_X)
        if df_test_pred_prob_all_columns.empty:
            df_test_pred_prob_all_columns = pd.DataFrame(data=test_linear_prediction_prob, columns=[columns[i]])
            df_train_pred_prob_all_columns = pd.DataFrame(data=train_linear_prediction_prob, columns=[columns[i]])
        else:
            df_test_pred_prob_all_columns[columns[i]]= pd.DataFrame(data=test_linear_prediction_prob, columns=[columns[i]])
            df_train_pred_prob_all_columns[columns[i]]= pd.DataFrame(data=train_linear_prediction_prob, columns=[columns[i]])

        log_content("  Training on class {}...".format(columns[i]))
        log_content("    MLT weights: {}".format(((trained_linear_model.get_weights()[0]).T)))
        log_content("    bias: {}".format(trained_linear_model.get_weights()[1]))
    
        ## Now train optimal thresholds, must use training data
        # keep probabilities for the positive outcome only. Must use TRAIN data
        yhat = trained_linear_model.predict(train_data_X)
        
        # calculate pr curve using TRAIN data
        best_th = get_best_pr(train_data_y, yhat, 'binary', acc_constraint)
        ## record optimal threshold for each class
        df_thresholds.append(best_th)
    return df_thresholds, df_test_pred_prob_all_columns, df_train_pred_prob_all_columns


# Apply threshold to positive probabilities to create labels
def to_labels(pos_probs, threshold):
	return (pos_probs >= threshold).astype('int')


## After apply individual threshold values in each class, combine all class as one final prediction
## orig_pred_prob: original predicted probabilities
## thresholds: trained optimal threshold values to apply in each class
## return new_pre: numpy array of final predictions after thresholds are applied and combined
def get_pred_after_threshold(original_pred_prob, thresholds):
    new_pred_all = []
    for i in range(len(thresholds)):
        globals() [f"new_pred_c{i}"] = to_labels(eval(f"original_pred_prob[:,i]"), eval(f"thresholds[i]"))
        new_pred_all.append(eval(f"new_pred_c{i}").T)
#         new_pred_c0 = to_labels(original_pred_prob[:,0], thresholds[0])
#         new_pred_c1 = to_labels(original_pred_prob[:,1], thresholds[1])
#         new_pred_c2 = to_labels(original_pred_prob[:,2], thresholds[2])
#         new_pred_c3 = to_labels(original_pred_prob[:,3], thresholds[3])
#         new_pred_c4 = to_labels(original_pred_prob[:,4], thresholds[4])

    #new_pred_all =[new_pred_c0.T, new_pred_c1.T, new_pred_c2.T, new_pred_c3.T, new_pred_c4.T]
    df_pred_all_columns = pd.DataFrame(data=new_pred_all)
    return df_pred_all_columns.to_numpy().T


# Display mean accuracy and std
def show_mean_score_std(scores, score_label, showPlot=True):
    local_contents = list()
    # print summary
    log_str = '{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format(score_label, mean(scores), std(scores), len(scores))
    #print('{0}: mean={1:.4f} std={2:.4f}, n={3:d}'.format(score_label, mean(scores), std(scores), len(scores)))
    local_contents.append(log_str)
    #log_content(sum_str, contents)
    if showPlot:
        # box and whisker plots of results
        plt.boxplot(scores)
        plt.show()
    return local_contents


# Get mean and std on specified metrics for a list of runs
# model_name: name of the model
# results: list of run results
# labels: labels of classes in the classifier
# metrics: specified metrics, such as accuracy, recall, precision, various F1 scores, etc
def get_mean_on_metrics(model_name, results, showPlot=True):
    local_contents = list()
    log_str = "Performance for {}:".format(model_name)
    local_contents.append(log_str)
    # Get average mean of accuracy
    accs = list()
    # Get average mean of macro F1
    mf1s = list()
    for i in range(len(results)):
        accs.append(results[i][1])
        mf1s.append(results[i][2])
    local_contents.append(show_mean_score_std(accs, 'Accuracy', showPlot))
    local_contents.append(show_mean_score_std(mf1s, 'Macro F1', showPlot))
    local_contents.append("\n")
    return local_contents
    

# Output contents to a file
def write_to_file():
#     f_name = ""
#     for model in models:
#         f_name = f_name + model + "_"
#     f_name = f_name + "M_C_results.txt"
    f_name = "MLT_TM_M_C_results.txt"
    with open(f_name, 'w') as f:
        for item in contents:
            if isinstance(item, list):
                for i in item:
                    f.write(str(i))
                    f.write(os.linesep)
            else:
                f.write(str(item))
                f.write(os.linesep)
                


def run_multi_combiner(models):
    # file name as key, df_data as value
    data_dic = {}
    dirs = list() # hold participating models' folder location
    model_info = list() # participating models' names (instead of m1, m2,..., etc)
    
    # Get all dev and test prob file names
    dev_file_list = list()
    test_file_list = list()
    
    for model in models:
        dirs.append(model_locs.get(model))
        model_info.append(model_dic.get(model))

    content = "Participated models are {}".format(model_info)
    log_content(content)
    
#     # Load all predicted prob files
#     all_model_prob_files = list() # it has probability files
    # Load all predicted probs from each file
    all_model_probs = list() # it has probability data and the file where it is from
    for directory in dirs:
        prob_file_path = directory
        #print("Probability file path {}".format(prob_file_path))
        dev_files = list() 
        test_files = list()
        dev_probs = list() # list of dictionary items
        test_probs = list() # list of dictionary items
    
        for file_name in sorted(glob.glob(prob_file_path + csv_file_pattern)):
            if (dev_file_pattern + prob_file_pattern) in file_name:
                dev_files.append(file_name)
            if (test_file_pattern + prob_file_pattern) in file_name:
                test_files.append(file_name)
            df_data = pd.read_csv(file_name)
            df_data.drop(columns=df_data.columns[-1],  axis=1,  inplace=True)
            data_dic.update({file_name: df_data})
            if dev_file_pattern in file_name:
                dev_probs.append([df_data, file_name])
            if test_file_pattern in file_name:
                test_probs.append([df_data, file_name])
        #all_model_prob_files.append((dev_files, test_files))
        dev_file_list.append(dev_files)
        test_file_list.append(test_files)
        all_model_probs.append([dev_probs, test_probs])
    
    # Create all permutations from paticipated individual models
    d_p = list(itertools.product(*dev_file_list))
    t_p = list(itertools.product(*test_file_list))
    
   # CAD test results for all runs before threshold moving
    results = list()
    # CAD test results for all runs after threshold moving
    results_tm = list() 

    # Loop through each run
    content = "There will be {} combining runs".format(len(d_p))
    log_content(content)

    ##TODO: get y_true once before the loop. No need to load all label files. 
    ## However, if each run due to multi-threading has a different id sequence,
    ## loading label id file for each run has to be done.
    for i in range(len(d_p)):
        log_content("Run at {}/{} ({})".format((i+1), len(d_p), model_info))
        train_X = list()
        test_X = list()
        labels_y = list()
        for model in range(len(models)):
            d_file = d_p[i][model]
            train_X.append(data_dic.get(d_file))
            t_file = t_p[i][model]
            test_X.append(data_dic.get(t_file))
            d_label_file = d_file.replace(prob_file_pattern, label_file_pattern)
            train_y = data_dic.get(d_label_file)
            t_label_file = t_file.replace(prob_file_pattern, label_file_pattern)
            test_y = data_dic.get(t_label_file)
#             get_participating_model_performance_1([d_file, t_file], data_dic.get(t_file), \
#                         test_y)
            individual_model_results = globals() [f"{models[model]}_results"]
            # Only run a single model run if it's not run before
            if t_file not in global_individual_run_list:
                global_individual_run_list.append(t_file)
                this_result = get_performance(np.round(data_dic.get(t_file)), test_y)
                individual_model_results.append(this_result)

        train_data_linear_dic, test_data_linear_dic =             get_dics_for_linear_combiner_1(models, train_X, test_X,                                                     train_y, test_y)
         
        df_trained_thresholds, df_test_pred_prob_all_columns, df_train_pred_prob_all_columns =                 train_linear_and_thresholds(models, train_data_linear_dic,                                                      test_data_linear_dic, classes)
        log_content("The trained TM values are {}".format(df_trained_thresholds))
        ## Evaluate results for linear combiner from all classes as one BEFORE weight adjust
        header_text = "\n---------------------MLT on CAD test---------------------"
        prob = df_test_pred_prob_all_columns.to_numpy()
        test_pred = np.round(prob)                                               
        results.append(log_performance(header_text, test_y, test_pred))

        ## Evaluate results for linear combiner from all classes as one AFTER using specified threshold value in each class
        after_pred= get_pred_after_threshold(df_test_pred_prob_all_columns.to_numpy(),                                              df_trained_thresholds)
        header_text = "-----------------------MLT-plus-TM on CAD test----------------"
        results_tm.append(log_performance(header_text, test_y, after_pred))  
    
    # Individual model performance
    for model in models:
        log_content(get_mean_on_metrics(model_dic[model],                 globals() [f"{model}_results"], False))
        
    # Get results for CAD per category
    category_idx = 0
    for category in classes:
        globals() [f"MLT_{category}_recalls"] = [results[i][0][0].get(str(category_idx)).get('recall')                 for i in range(len(d_p))]
        globals() [f"MLT_{category}_precisions"] = [results[i][0][0].get(str(category_idx)).get('precision')                 for i in range(len(d_p))]
        globals() [f"MLT_{category}_f1s"] = [results[i][0][0].get(str(category_idx)).get('f1-score')                 for i in range(len(d_p))]
        
        # MLT-plus-TM results per category
        globals() [f"MLT_TM_{category}_recalls"] = [results_tm[i][0][0].get(str(category_idx)).get('recall')                 for i in range(len(d_p))]
        globals() [f"MLT_TM_{category}_precisions"] = [results_tm[i][0][0].get(str(category_idx)).get('precision')                 for i in range(len(d_p))]
        globals() [f"MLT_TM_{category}_f1s"] = [results_tm[i][0][0].get(str(category_idx)).get('f1-score')                 for i in range(len(d_p))]

        category_idx = category_idx + 1
    
    # MLT performance
    log_content(get_mean_on_metrics('MLT', results, False))
    log_content("\nPerformance for CAD MLT per category:")
    for category in classes:
        current_recalls = eval(f"MLT_{category}_recalls")
        current_precisions = eval(f"MLT_{category}_precisions")
        current_f1s = eval(f"MLT_{category}_f1s")
        
        log_content('{0} recall: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_recalls),                std(current_recalls), len(current_recalls)))
        log_content('{0} precision: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_precisions),                std(current_precisions), len(current_precisions)))
        log_content('{0} macro f1: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_f1s),                std(current_f1s), len(current_f1s)))
    log_content("\n")

    # MLT-plus-TM performance
    log_content(get_mean_on_metrics('MLT-plus-TM', results_tm, False))
    log_content("\nPerformance for CAD MLT-plus-TM per category:")
    for category in classes:
        current_recalls = eval(f"MLT_TM_{category}_recalls")
        current_precisions = eval(f"MLT_TM_{category}_precisions")
        current_f1s = eval(f"MLT_TM_{category}_f1s")
        log_content('{0} recall: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_recalls),                std(current_recalls), len(current_recalls)))
        log_content('{0} precision: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_precisions),                std(current_precisions), len(current_precisions)))
        log_content('{0} macro f1: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_f1s),                std(current_f1s), len(current_f1s)))
    
    log_str = "\nMLT performance in each run"
    log_content(log_str)
    for i in range(len(results)):
        log_str = "Accuracy is {}, macro f1 is {} at {}".format(results[i][1],                                 results[i][2], i)
        log_content(log_str)
    
    log_str = "\nMLT-plus-TM performance in each run"
    log_content(log_str)
    for i in range(len(results_tm)):
        log_str = "Accuracy is {}, macro f1 is {} at {}".format(results_tm[i][1],                                 results_tm[i][2], i)
        log_content(log_str)
        
    mf1s = [results[i][2] for i in range(len(d_p))]
    accs = [results[i][1] for i in range(len(d_p))]
    accmf1 = [(mf1s[i] + accs[i]) for i in range(len(d_p))]

    mf1s_tm = [results_tm[i][2] for i in range(len(d_p))]
    accs_tm = [results_tm[i][1] for i in range(len(d_p))]
    accmf1_tm = [(mf1s_tm[i] + accs_tm[i]) for i in range(len(d_p))]
    
    return [mean(accmf1), mean(accmf1_tm),            mean(mf1s), mean(accs), mean(mf1s_tm), mean(accs_tm)]


combiner_results = dict()
tm_combiner_results = dict()

combine_count = 0
for L in range(len(models) + 1):
    for subset in itertools.combinations(models, L):
        if (len(subset) > 1):
            combine_count = combine_count + 1
log_content("There will be {} number of combinations. Each combination will have multiple runs.".format(combine_count))

for L in range(len(models) + 1):
    for subset in itertools.combinations(models, L):
        if (len(subset) > 1):
            [v1, v2, v3, v4, v5,v6] = run_multi_combiner(subset)
            combiner_results.update({subset: [v1, v3, v4]})
            tm_combiner_results.update({subset: [v2, v5, v6]})


# Sort the results based on performance metric
top_n = 1
results_list = list(combiner_results.items())
# sorted using macro F1
sorted_results_list = sorted(results_list, key = lambda x: x[1][1], reverse=True)
log_content("\n")
log_content("MLT performance in Macro F1 scores order")
for result in sorted_results_list:
    log_content(result)

tm_results_list = list(tm_combiner_results.items())
# sorted using macro F1
tm_sorted_results_list = sorted(tm_results_list, key = lambda x: x[1][1], reverse=True)
log_content("\n")
log_content("MLT-plus-TM performance in Macro F1 scores order")
for result in tm_sorted_results_list:
    log_content(result)
    
# sorted using accuracy+macro F1
sorted_results_list = sorted(results_list, key = lambda x: x[1][0], reverse=True)
log_content("\n")
log_content("MLT performance in Accuracy + Macro F1 scores order")
for result in sorted_results_list:
    log_content(result)
    
# sorted using accuracy+macro F1
tm_sorted_results_list = sorted(tm_results_list, key = lambda x: x[1][0], reverse=True)
log_content("\n")
log_content("MLT-plus-TM performance in Accuracy + Macro F1 scores order")
for result in tm_sorted_results_list:
    log_content(result)


for model in models:
    # results for all individual runs
    results = globals() [f"{model}_results"]
    log_content("Model {} per category performance:".format(model_dic[model]))
    category_idx = 0
    for category in classes:
        current_recalls = [results[i][0][0].get(str(category_idx)).get('recall')                 for i in range(len(results))]
        current_precisions = [results[i][0][0].get(str(category_idx)).get('precision')                 for i in range(len(results))]
        current_f1s = [results[i][0][0].get(str(category_idx)).get('f1-score')                 for i in range(len(results))]
        log_content('{0} recall: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_recalls),                std(current_recalls), len(current_recalls)))
        log_content('{0} precisions: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_precisions),                std(current_precisions), len(current_precisions)))
        log_content('{0} macro f1: mean={1:.4f} std={2:.4f}, n={3:d}'.            format(category, mean(current_f1s),                std(current_f1s), len(current_f1s)))
        category_idx = category_idx + 1
    log_content("\n")


write_to_file()




